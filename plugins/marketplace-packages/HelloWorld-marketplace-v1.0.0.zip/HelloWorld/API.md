# HelloWorld API Documentation

## Overview

A simple hello world plugin for Shopologic

