# HelloWorld Hooks Documentation

## Overview

This document describes all hooks (actions and filters) provided by the HelloWorld plugin.

