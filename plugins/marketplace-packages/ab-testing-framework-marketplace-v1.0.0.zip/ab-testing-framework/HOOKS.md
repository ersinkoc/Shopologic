# A/B Testing Framework Hooks Documentation

## Overview

This document describes all hooks (actions and filters) provided by the A/B Testing Framework plugin.

## Actions

### `page.rendered`

Description: TODO

Parameters:
- TODO

Example:
```php
add_action('page.rendered', function($param) {
    // Your code here
});
```

### `order.completed`

Description: TODO

Parameters:
- TODO

Example:
```php
add_action('order.completed', function($param) {
    // Your code here
});
```

### `experiment.variant_shown`

Description: TODO

Parameters:
- TODO

Example:
```php
add_action('experiment.variant_shown', function($param) {
    // Your code here
});
```

### `admin.experiments.dashboard`

Description: TODO

Parameters:
- TODO

Example:
```php
add_action('admin.experiments.dashboard', function($param) {
    // Your code here
});
```

