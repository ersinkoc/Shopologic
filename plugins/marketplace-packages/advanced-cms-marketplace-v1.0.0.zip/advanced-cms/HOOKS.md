# advanced-cms Hooks Documentation

## Overview

Hooks provided by the advanced-cms plugin.

## Actions

### `content.created`

Description: TODO - Add action description

Example:
```php
add_action('content.created', function($data) {
    // Your code here
});
```

### `content.published`

Description: TODO - Add action description

Example:
```php
add_action('content.published', function($data) {
    // Your code here
});
```

### `seo.optimized`

Description: TODO - Add action description

Example:
```php
add_action('seo.optimized', function($data) {
    // Your code here
});
```

### `content.personalized`

Description: TODO - Add action description

Example:
```php
add_action('content.personalized', function($data) {
    // Your code here
});
```

### `translation.generated`

Description: TODO - Add action description

Example:
```php
add_action('translation.generated', function($data) {
    // Your code here
});
```

