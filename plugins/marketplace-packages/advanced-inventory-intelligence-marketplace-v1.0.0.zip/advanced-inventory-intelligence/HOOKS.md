# advanced-inventory-intelligence Hooks Documentation

## Overview

Hooks provided by the advanced-inventory-intelligence plugin.

## Actions

### `inventory.level_changed`

Description: TODO - Add action description

Example:
```php
add_action('inventory.level_changed', function($data) {
    // Your code here
});
```

### `order.completed`

Description: TODO - Add action description

Example:
```php
add_action('order.completed', function($data) {
    // Your code here
});
```

### `product.demand_spike`

Description: TODO - Add action description

Example:
```php
add_action('product.demand_spike', function($data) {
    // Your code here
});
```

### `supplier.performance_updated`

Description: TODO - Add action description

Example:
```php
add_action('supplier.performance_updated', function($data) {
    // Your code here
});
```

### `forecast.generated`

Description: TODO - Add action description

Example:
```php
add_action('forecast.generated', function($data) {
    // Your code here
});
```

