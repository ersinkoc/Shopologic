# advanced-personalization-engine Hooks Documentation

## Overview

Hooks provided by the advanced-personalization-engine plugin.

## Actions

### `personalization.profile_updated`

Description: TODO - Add action description

Example:
```php
add_action('personalization.profile_updated', function($data) {
    // Your code here
});
```

### `behavior.event_tracked`

Description: TODO - Add action description

Example:
```php
add_action('behavior.event_tracked', function($data) {
    // Your code here
});
```

### `recommendation.generated`

Description: TODO - Add action description

Example:
```php
add_action('recommendation.generated', function($data) {
    // Your code here
});
```

### `content.personalized`

Description: TODO - Add action description

Example:
```php
add_action('content.personalized', function($data) {
    // Your code here
});
```

### `segment.customer_moved`

Description: TODO - Add action description

Example:
```php
add_action('segment.customer_moved', function($data) {
    // Your code here
});
```

