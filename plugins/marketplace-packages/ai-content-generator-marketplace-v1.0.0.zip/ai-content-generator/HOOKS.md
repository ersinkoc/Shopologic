# ai-content-generator Hooks Documentation

## Overview

Hooks provided by the ai-content-generator plugin.

## Actions

### `content.generated`

Description: TODO - Add action description

Example:
```php
add_action('content.generated', function($data) {
    // Your code here
});
```

### `content.approved`

Description: TODO - Add action description

Example:
```php
add_action('content.approved', function($data) {
    // Your code here
});
```

### `content.rejected`

Description: TODO - Add action description

Example:
```php
add_action('content.rejected', function($data) {
    // Your code here
});
```

### `model.trained`

Description: TODO - Add action description

Example:
```php
add_action('model.trained', function($data) {
    // Your code here
});
```

### `template.created`

Description: TODO - Add action description

Example:
```php
add_action('template.created', function($data) {
    // Your code here
});
```

### `generation.started`

Description: TODO - Add action description

Example:
```php
add_action('generation.started', function($data) {
    // Your code here
});
```

### `generation.completed`

Description: TODO - Add action description

Example:
```php
add_action('generation.completed', function($data) {
    // Your code here
});
```

## Filters

### `ai.prompt`

Description: TODO - Add filter description

Example:
```php
add_filter('ai.prompt', function($value) {
    return $value;
});
```

### `ai.response`

Description: TODO - Add filter description

Example:
```php
add_filter('ai.response', function($value) {
    return $value;
});
```

### `content.quality`

Description: TODO - Add filter description

Example:
```php
add_filter('content.quality', function($value) {
    return $value;
});
```

### `content.seo_score`

Description: TODO - Add filter description

Example:
```php
add_filter('content.seo_score', function($value) {
    return $value;
});
```

### `generation.parameters`

Description: TODO - Add filter description

Example:
```php
add_filter('generation.parameters', function($value) {
    return $value;
});
```

