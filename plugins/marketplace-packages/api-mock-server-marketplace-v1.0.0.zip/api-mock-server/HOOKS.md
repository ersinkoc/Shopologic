# api-mock-server Hooks Documentation

## Overview

Hooks provided by the api-mock-server plugin.

## Actions

### `mock.created`

Description: TODO - Add action description

Example:
```php
add_action('mock.created', function($data) {
    // Your code here
});
```

### `mock.updated`

Description: TODO - Add action description

Example:
```php
add_action('mock.updated', function($data) {
    // Your code here
});
```

### `request.recorded`

Description: TODO - Add action description

Example:
```php
add_action('request.recorded', function($data) {
    // Your code here
});
```

### `scenario.executed`

Description: TODO - Add action description

Example:
```php
add_action('scenario.executed', function($data) {
    // Your code here
});
```

### `response.generated`

Description: TODO - Add action description

Example:
```php
add_action('response.generated', function($data) {
    // Your code here
});
```

## Filters

### `api.request`

Description: TODO - Add filter description

Example:
```php
add_filter('api.request', function($value) {
    return $value;
});
```

### `api.response`

Description: TODO - Add filter description

Example:
```php
add_filter('api.response', function($value) {
    return $value;
});
```

### `mock.response`

Description: TODO - Add filter description

Example:
```php
add_filter('mock.response', function($value) {
    return $value;
});
```

### `request.validation`

Description: TODO - Add filter description

Example:
```php
add_filter('request.validation', function($value) {
    return $value;
});
```

### `response.transformation`

Description: TODO - Add filter description

Example:
```php
add_filter('response.transformation', function($value) {
    return $value;
});
```

