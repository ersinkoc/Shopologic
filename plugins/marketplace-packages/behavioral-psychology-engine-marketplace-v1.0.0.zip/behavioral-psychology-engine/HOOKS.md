# behavioral-psychology-engine Hooks Documentation

## Overview

Hooks provided by the behavioral-psychology-engine plugin.

## Actions

### `page.product_view`

Description: TODO - Add action description

Example:
```php
add_action('page.product_view', function($data) {
    // Your code here
});
```

### `cart.item_added`

Description: TODO - Add action description

Example:
```php
add_action('cart.item_added', function($data) {
    // Your code here
});
```

### `checkout.initiated`

Description: TODO - Add action description

Example:
```php
add_action('checkout.initiated', function($data) {
    // Your code here
});
```

### `user.behavior_tracked`

Description: TODO - Add action description

Example:
```php
add_action('user.behavior_tracked', function($data) {
    // Your code here
});
```

### `conversion.opportunity_detected`

Description: TODO - Add action description

Example:
```php
add_action('conversion.opportunity_detected', function($data) {
    // Your code here
});
```

