# blockchain-supply-chain Hooks Documentation

## Overview

Hooks provided by the blockchain-supply-chain plugin.

## Actions

### `product.manufactured`

Description: TODO - Add action description

Example:
```php
add_action('product.manufactured', function($data) {
    // Your code here
});
```

### `product.shipped`

Description: TODO - Add action description

Example:
```php
add_action('product.shipped', function($data) {
    // Your code here
});
```

### `product.received`

Description: TODO - Add action description

Example:
```php
add_action('product.received', function($data) {
    // Your code here
});
```

### `order.verified`

Description: TODO - Add action description

Example:
```php
add_action('order.verified', function($data) {
    // Your code here
});
```

### `supply.chain.updated`

Description: TODO - Add action description

Example:
```php
add_action('supply.chain.updated', function($data) {
    // Your code here
});
```

