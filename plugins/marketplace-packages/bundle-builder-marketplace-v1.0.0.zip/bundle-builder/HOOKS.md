# Smart Bundle Builder Hooks Documentation

## Overview

Hooks provided by the Smart Bundle Builder plugin.

## Actions

### `product.display`

Description: TODO - Add action description

Example:
```php
add_action('product.display', function($data) {
    // Your code here
});
```

### `cart.updated`

Description: TODO - Add action description

Example:
```php
add_action('cart.updated', function($data) {
    // Your code here
});
```

### `admin.product.form`

Description: TODO - Add action description

Example:
```php
add_action('admin.product.form', function($data) {
    // Your code here
});
```

