# customer-lifetime-value-optimizer Hooks Documentation

## Overview

Hooks provided by the customer-lifetime-value-optimizer plugin.

## Actions

### `customer.clv_updated`

Description: TODO - Add action description

Example:
```php
add_action('customer.clv_updated', function($data) {
    // Your code here
});
```

### `customer.churn_risk_detected`

Description: TODO - Add action description

Example:
```php
add_action('customer.churn_risk_detected', function($data) {
    // Your code here
});
```

### `customer.segment_changed`

Description: TODO - Add action description

Example:
```php
add_action('customer.segment_changed', function($data) {
    // Your code here
});
```

### `customer.retention_triggered`

Description: TODO - Add action description

Example:
```php
add_action('customer.retention_triggered', function($data) {
    // Your code here
});
```

### `order.clv_impact_calculated`

Description: TODO - Add action description

Example:
```php
add_action('order.clv_impact_calculated', function($data) {
    // Your code here
});
```

