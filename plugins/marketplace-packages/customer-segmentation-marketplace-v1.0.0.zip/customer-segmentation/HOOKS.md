# Customer Segmentation Engine Hooks Documentation

## Overview

Hooks provided by the Customer Segmentation Engine plugin.

## Actions

### `customer.registered`

Description: TODO - Add action description

Example:
```php
add_action('customer.registered', function($data) {
    // Your code here
});
```

### `order.completed`

Description: TODO - Add action description

Example:
```php
add_action('order.completed', function($data) {
    // Your code here
});
```

### `customer.login`

Description: TODO - Add action description

Example:
```php
add_action('customer.login', function($data) {
    // Your code here
});
```

### `product.viewed`

Description: TODO - Add action description

Example:
```php
add_action('product.viewed', function($data) {
    // Your code here
});
```

### `admin.customers.dashboard`

Description: TODO - Add action description

Example:
```php
add_action('admin.customers.dashboard', function($data) {
    // Your code here
});
```

