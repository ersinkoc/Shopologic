# enterprise-security-compliance Hooks Documentation

## Overview

Hooks provided by the enterprise-security-compliance plugin.

## Actions

### `user.login`

Description: TODO - Add action description

Example:
```php
add_action('user.login', function($data) {
    // Your code here
});
```

### `user.action`

Description: TODO - Add action description

Example:
```php
add_action('user.action', function($data) {
    // Your code here
});
```

### `data.accessed`

Description: TODO - Add action description

Example:
```php
add_action('data.accessed', function($data) {
    // Your code here
});
```

### `security.threat_detected`

Description: TODO - Add action description

Example:
```php
add_action('security.threat_detected', function($data) {
    // Your code here
});
```

### `compliance.audit_required`

Description: TODO - Add action description

Example:
```php
add_action('compliance.audit_required', function($data) {
    // Your code here
});
```

