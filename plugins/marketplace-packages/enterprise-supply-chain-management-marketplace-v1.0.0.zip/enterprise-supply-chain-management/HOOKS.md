# enterprise-supply-chain-management Hooks Documentation

## Overview

Hooks provided by the enterprise-supply-chain-management plugin.

## Actions

### `supply_chain.shipment_created`

Description: TODO - Add action description

Example:
```php
add_action('supply_chain.shipment_created', function($data) {
    // Your code here
});
```

### `supplier.performance_updated`

Description: TODO - Add action description

Example:
```php
add_action('supplier.performance_updated', function($data) {
    // Your code here
});
```

### `logistics.route_optimized`

Description: TODO - Add action description

Example:
```php
add_action('logistics.route_optimized', function($data) {
    // Your code here
});
```

### `supply_chain.disruption_detected`

Description: TODO - Add action description

Example:
```php
add_action('supply_chain.disruption_detected', function($data) {
    // Your code here
});
```

### `blockchain.transaction_recorded`

Description: TODO - Add action description

Example:
```php
add_action('blockchain.transaction_recorded', function($data) {
    // Your code here
});
```

