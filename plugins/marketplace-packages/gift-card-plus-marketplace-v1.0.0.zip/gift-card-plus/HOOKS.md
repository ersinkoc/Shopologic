# Gift Card Plus Hooks Documentation

## Overview

Hooks provided by the Gift Card Plus plugin.

## Actions

### `checkout.payment_methods`

Description: TODO - Add action description

Example:
```php
add_action('checkout.payment_methods', function($data) {
    // Your code here
});
```

### `order.completed`

Description: TODO - Add action description

Example:
```php
add_action('order.completed', function($data) {
    // Your code here
});
```

### `gift_card.redeemed`

Description: TODO - Add action description

Example:
```php
add_action('gift_card.redeemed', function($data) {
    // Your code here
});
```

### `frontend.gift_card_form`

Description: TODO - Add action description

Example:
```php
add_action('frontend.gift_card_form', function($data) {
    // Your code here
});
```

