# graphql-schema-builder Hooks Documentation

## Overview

Hooks provided by the graphql-schema-builder plugin.

## Actions

### `graphql.schema_updated`

Description: TODO - Add action description

Example:
```php
add_action('graphql.schema_updated', function($data) {
    // Your code here
});
```

### `graphql.type_created`

Description: TODO - Add action description

Example:
```php
add_action('graphql.type_created', function($data) {
    // Your code here
});
```

### `graphql.resolver_registered`

Description: TODO - Add action description

Example:
```php
add_action('graphql.resolver_registered', function($data) {
    // Your code here
});
```

### `graphql.query_executed`

Description: TODO - Add action description

Example:
```php
add_action('graphql.query_executed', function($data) {
    // Your code here
});
```

### `graphql.subscription_connected`

Description: TODO - Add action description

Example:
```php
add_action('graphql.subscription_connected', function($data) {
    // Your code here
});
```

### `graphql.error_occurred`

Description: TODO - Add action description

Example:
```php
add_action('graphql.error_occurred', function($data) {
    // Your code here
});
```

## Filters

### `graphql.schema`

Description: TODO - Add filter description

Example:
```php
add_filter('graphql.schema', function($value) {
    return $value;
});
```

### `graphql.types`

Description: TODO - Add filter description

Example:
```php
add_filter('graphql.types', function($value) {
    return $value;
});
```

### `graphql.resolvers`

Description: TODO - Add filter description

Example:
```php
add_filter('graphql.resolvers', function($value) {
    return $value;
});
```

### `graphql.context`

Description: TODO - Add filter description

Example:
```php
add_filter('graphql.context', function($value) {
    return $value;
});
```

### `graphql.validation_rules`

Description: TODO - Add filter description

Example:
```php
add_filter('graphql.validation_rules', function($value) {
    return $value;
});
```

### `graphql.query_complexity`

Description: TODO - Add filter description

Example:
```php
add_filter('graphql.query_complexity', function($value) {
    return $value;
});
```

