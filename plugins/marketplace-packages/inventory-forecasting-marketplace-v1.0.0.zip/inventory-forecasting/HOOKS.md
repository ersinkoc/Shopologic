# Smart Inventory Forecasting Hooks Documentation

## Overview

Hooks provided by the Smart Inventory Forecasting plugin.

## Actions

### `order.completed`

Description: TODO - Add action description

Example:
```php
add_action('order.completed', function($data) {
    // Your code here
});
```

### `inventory.updated`

Description: TODO - Add action description

Example:
```php
add_action('inventory.updated', function($data) {
    // Your code here
});
```

### `product.low_stock`

Description: TODO - Add action description

Example:
```php
add_action('product.low_stock', function($data) {
    // Your code here
});
```

### `admin.inventory.dashboard`

Description: TODO - Add action description

Example:
```php
add_action('admin.inventory.dashboard', function($data) {
    // Your code here
});
```

