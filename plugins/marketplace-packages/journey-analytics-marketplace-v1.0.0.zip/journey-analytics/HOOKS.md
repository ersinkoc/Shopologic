# Customer Journey Analytics Hooks Documentation

## Overview

Hooks provided by the Customer Journey Analytics plugin.

## Actions

### `page.viewed`

Description: TODO - Add action description

Example:
```php
add_action('page.viewed', function($data) {
    // Your code here
});
```

### `product.viewed`

Description: TODO - Add action description

Example:
```php
add_action('product.viewed', function($data) {
    // Your code here
});
```

### `cart.item_added`

Description: TODO - Add action description

Example:
```php
add_action('cart.item_added', function($data) {
    // Your code here
});
```

### `order.completed`

Description: TODO - Add action description

Example:
```php
add_action('order.completed', function($data) {
    // Your code here
});
```

### `customer.searched`

Description: TODO - Add action description

Example:
```php
add_action('customer.searched', function($data) {
    // Your code here
});
```

