# Live Chat Support Hooks Documentation

## Overview

Hooks provided by the Live Chat Support plugin.

## Actions

### `Array`

Description: TODO - Add action description

Example:
```php
add_action('Array', function($data) {
    // Your code here
});
```

### `Array`

Description: TODO - Add action description

Example:
```php
add_action('Array', function($data) {
    // Your code here
});
```

### `Array`

Description: TODO - Add action description

Example:
```php
add_action('Array', function($data) {
    // Your code here
});
```

### `Array`

Description: TODO - Add action description

Example:
```php
add_action('Array', function($data) {
    // Your code here
});
```

