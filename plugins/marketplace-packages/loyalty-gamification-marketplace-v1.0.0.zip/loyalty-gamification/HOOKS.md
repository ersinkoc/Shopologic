# Loyalty Gamification Hooks Documentation

## Overview

Hooks provided by the Loyalty Gamification plugin.

## Actions

### `customer.registered`

Description: TODO - Add action description

Example:
```php
add_action('customer.registered', function($data) {
    // Your code here
});
```

### `order.completed`

Description: TODO - Add action description

Example:
```php
add_action('order.completed', function($data) {
    // Your code here
});
```

### `product.reviewed`

Description: TODO - Add action description

Example:
```php
add_action('product.reviewed', function($data) {
    // Your code here
});
```

### `customer.birthday`

Description: TODO - Add action description

Example:
```php
add_action('customer.birthday', function($data) {
    // Your code here
});
```

### `social.shared`

Description: TODO - Add action description

Example:
```php
add_action('social.shared', function($data) {
    // Your code here
});
```

