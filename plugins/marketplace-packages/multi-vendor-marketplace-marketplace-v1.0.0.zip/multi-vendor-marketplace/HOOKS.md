# Multi-Vendor Marketplace Hooks Documentation

## Overview

Hooks provided by the Multi-Vendor Marketplace plugin.

## Actions

### `vendor.registered`

Description: TODO - Add action description

Example:
```php
add_action('vendor.registered', function($data) {
    // Your code here
});
```

### `product.submitted`

Description: TODO - Add action description

Example:
```php
add_action('product.submitted', function($data) {
    // Your code here
});
```

### `order.completed`

Description: TODO - Add action description

Example:
```php
add_action('order.completed', function($data) {
    // Your code here
});
```

### `commission.calculated`

Description: TODO - Add action description

Example:
```php
add_action('commission.calculated', function($data) {
    // Your code here
});
```

### `admin.vendor.dashboard`

Description: TODO - Add action description

Example:
```php
add_action('admin.vendor.dashboard', function($data) {
    // Your code here
});
```

