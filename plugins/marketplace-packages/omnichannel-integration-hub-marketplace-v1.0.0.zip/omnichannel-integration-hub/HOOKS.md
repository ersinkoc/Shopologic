# omnichannel-integration-hub Hooks Documentation

## Overview

Hooks provided by the omnichannel-integration-hub plugin.

## Actions

### `order.created`

Description: TODO - Add action description

Example:
```php
add_action('order.created', function($data) {
    // Your code here
});
```

### `inventory.updated`

Description: TODO - Add action description

Example:
```php
add_action('inventory.updated', function($data) {
    // Your code here
});
```

### `product.synced`

Description: TODO - Add action description

Example:
```php
add_action('product.synced', function($data) {
    // Your code here
});
```

### `customer.unified`

Description: TODO - Add action description

Example:
```php
add_action('customer.unified', function($data) {
    // Your code here
});
```

### `channel.connected`

Description: TODO - Add action description

Example:
```php
add_action('channel.connected', function($data) {
    // Your code here
});
```

