# payment-stripe Hooks Documentation

## Overview

Hooks provided by the payment-stripe plugin.

## Actions

### `order.created`

Description: TODO - Add action description

Example:
```php
add_action('order.created', function($data) {
    // Your code here
});
```

### `payment.processing`

Description: TODO - Add action description

Example:
```php
add_action('payment.processing', function($data) {
    // Your code here
});
```

### `payment.completed`

Description: TODO - Add action description

Example:
```php
add_action('payment.completed', function($data) {
    // Your code here
});
```

### `payment.failed`

Description: TODO - Add action description

Example:
```php
add_action('payment.failed', function($data) {
    // Your code here
});
```

### `refund.processing`

Description: TODO - Add action description

Example:
```php
add_action('refund.processing', function($data) {
    // Your code here
});
```

### `refund.completed`

Description: TODO - Add action description

Example:
```php
add_action('refund.completed', function($data) {
    // Your code here
});
```

