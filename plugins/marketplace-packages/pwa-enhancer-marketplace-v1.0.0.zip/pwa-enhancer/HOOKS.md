# PWA Enhancer Hooks Documentation

## Overview

Hooks provided by the PWA Enhancer plugin.

## Actions

### `frontend.head`

Description: TODO - Add action description

Example:
```php
add_action('frontend.head', function($data) {
    // Your code here
});
```

### `frontend.manifest`

Description: TODO - Add action description

Example:
```php
add_action('frontend.manifest', function($data) {
    // Your code here
});
```

### `service_worker.install`

Description: TODO - Add action description

Example:
```php
add_action('service_worker.install', function($data) {
    // Your code here
});
```

### `order.completed`

Description: TODO - Add action description

Example:
```php
add_action('order.completed', function($data) {
    // Your code here
});
```

