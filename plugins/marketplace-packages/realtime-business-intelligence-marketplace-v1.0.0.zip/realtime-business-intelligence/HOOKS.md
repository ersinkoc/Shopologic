# realtime-business-intelligence Hooks Documentation

## Overview

Hooks provided by the realtime-business-intelligence plugin.

## Actions

### `order.created`

Description: TODO - Add action description

Example:
```php
add_action('order.created', function($data) {
    // Your code here
});
```

### `user.activity`

Description: TODO - Add action description

Example:
```php
add_action('user.activity', function($data) {
    // Your code here
});
```

### `analytics.metric_updated`

Description: TODO - Add action description

Example:
```php
add_action('analytics.metric_updated', function($data) {
    // Your code here
});
```

### `dashboard.data_request`

Description: TODO - Add action description

Example:
```php
add_action('dashboard.data_request', function($data) {
    // Your code here
});
```

### `alert.threshold_exceeded`

Description: TODO - Add action description

Example:
```php
add_action('alert.threshold_exceeded', function($data) {
    // Your code here
});
```

