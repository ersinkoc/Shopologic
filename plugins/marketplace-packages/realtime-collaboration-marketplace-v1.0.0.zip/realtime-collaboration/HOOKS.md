# realtime-collaboration Hooks Documentation

## Overview

Hooks provided by the realtime-collaboration plugin.

## Actions

### `collaboration.room_created`

Description: TODO - Add action description

Example:
```php
add_action('collaboration.room_created', function($data) {
    // Your code here
});
```

### `collaboration.user_joined`

Description: TODO - Add action description

Example:
```php
add_action('collaboration.user_joined', function($data) {
    // Your code here
});
```

### `collaboration.user_left`

Description: TODO - Add action description

Example:
```php
add_action('collaboration.user_left', function($data) {
    // Your code here
});
```

### `collaboration.content_changed`

Description: TODO - Add action description

Example:
```php
add_action('collaboration.content_changed', function($data) {
    // Your code here
});
```

### `collaboration.screen_shared`

Description: TODO - Add action description

Example:
```php
add_action('collaboration.screen_shared', function($data) {
    // Your code here
});
```

### `collaboration.call_started`

Description: TODO - Add action description

Example:
```php
add_action('collaboration.call_started', function($data) {
    // Your code here
});
```

### `collaboration.call_ended`

Description: TODO - Add action description

Example:
```php
add_action('collaboration.call_ended', function($data) {
    // Your code here
});
```

### `collaboration.message_sent`

Description: TODO - Add action description

Example:
```php
add_action('collaboration.message_sent', function($data) {
    // Your code here
});
```

## Filters

### `collaboration.permissions`

Description: TODO - Add filter description

Example:
```php
add_filter('collaboration.permissions', function($value) {
    return $value;
});
```

### `collaboration.room_settings`

Description: TODO - Add filter description

Example:
```php
add_filter('collaboration.room_settings', function($value) {
    return $value;
});
```

### `collaboration.user_capabilities`

Description: TODO - Add filter description

Example:
```php
add_filter('collaboration.user_capabilities', function($value) {
    return $value;
});
```

### `collaboration.content_sync`

Description: TODO - Add filter description

Example:
```php
add_filter('collaboration.content_sync', function($value) {
    return $value;
});
```

### `collaboration.presence_data`

Description: TODO - Add filter description

Example:
```php
add_filter('collaboration.presence_data', function($value) {
    return $value;
});
```

