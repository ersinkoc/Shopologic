# Review Intelligence Hooks Documentation

## Overview

Hooks provided by the Review Intelligence plugin.

## Actions

### `review.submitted`

Description: TODO - Add action description

Example:
```php
add_action('review.submitted', function($data) {
    // Your code here
});
```

### `review.moderated`

Description: TODO - Add action description

Example:
```php
add_action('review.moderated', function($data) {
    // Your code here
});
```

### `order.completed`

Description: TODO - Add action description

Example:
```php
add_action('order.completed', function($data) {
    // Your code here
});
```

### `product.display`

Description: TODO - Add action description

Example:
```php
add_action('product.display', function($data) {
    // Your code here
});
```

