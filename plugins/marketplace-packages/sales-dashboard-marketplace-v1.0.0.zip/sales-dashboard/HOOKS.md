# Sales Performance Dashboard Hooks Documentation

## Overview

Hooks provided by the Sales Performance Dashboard plugin.

## Actions

### `order.completed`

Description: TODO - Add action description

Example:
```php
add_action('order.completed', function($data) {
    // Your code here
});
```

### `admin.dashboard.widgets`

Description: TODO - Add action description

Example:
```php
add_action('admin.dashboard.widgets', function($data) {
    // Your code here
});
```

### `reports.scheduled`

Description: TODO - Add action description

Example:
```php
add_action('reports.scheduled', function($data) {
    // Your code here
});
```

### `analytics.updated`

Description: TODO - Add action description

Example:
```php
add_action('analytics.updated', function($data) {
    // Your code here
});
```

