# shipping-fedex Hooks Documentation

## Overview

Hooks provided by the shipping-fedex plugin.

## Actions

### `order.shipped`

Description: TODO - Add action description

Example:
```php
add_action('order.shipped', function($data) {
    // Your code here
});
```

### `shipping.calculate`

Description: TODO - Add action description

Example:
```php
add_action('shipping.calculate', function($data) {
    // Your code here
});
```

### `shipping.label.generate`

Description: TODO - Add action description

Example:
```php
add_action('shipping.label.generate', function($data) {
    // Your code here
});
```

### `shipping.tracking.update`

Description: TODO - Add action description

Example:
```php
add_action('shipping.tracking.update', function($data) {
    // Your code here
});
```

