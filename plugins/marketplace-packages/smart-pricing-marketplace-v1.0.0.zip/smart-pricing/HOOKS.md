# Smart Pricing Engine Hooks Documentation

## Overview

Hooks provided by the Smart Pricing Engine plugin.

## Actions

### `product.price_calculated`

Description: TODO - Add action description

Example:
```php
add_action('product.price_calculated', function($data) {
    // Your code here
});
```

### `order.completed`

Description: TODO - Add action description

Example:
```php
add_action('order.completed', function($data) {
    // Your code here
});
```

### `inventory.updated`

Description: TODO - Add action description

Example:
```php
add_action('inventory.updated', function($data) {
    // Your code here
});
```

### `admin.pricing_rules`

Description: TODO - Add action description

Example:
```php
add_action('admin.pricing_rules', function($data) {
    // Your code here
});
```

