# smart-search-discovery Hooks Documentation

## Overview

Hooks provided by the smart-search-discovery plugin.

## Actions

### `search.query`

Description: TODO - Add action description

Example:
```php
add_action('search.query', function($data) {
    // Your code here
});
```

### `search.results`

Description: TODO - Add action description

Example:
```php
add_action('search.results', function($data) {
    // Your code here
});
```

### `product.discovery`

Description: TODO - Add action description

Example:
```php
add_action('product.discovery', function($data) {
    // Your code here
});
```

### `user.search_behavior`

Description: TODO - Add action description

Example:
```php
add_action('user.search_behavior', function($data) {
    // Your code here
});
```

### `content.index`

Description: TODO - Add action description

Example:
```php
add_action('content.index', function($data) {
    // Your code here
});
```

