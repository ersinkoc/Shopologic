# Smart Search Engine Hooks Documentation

## Overview

Hooks provided by the Smart Search Engine plugin.

## Actions

### `search.query`

Description: TODO - Add action description

Example:
```php
add_action('search.query', function($data) {
    // Your code here
});
```

### `product.indexed`

Description: TODO - Add action description

Example:
```php
add_action('product.indexed', function($data) {
    // Your code here
});
```

### `search.autocomplete`

Description: TODO - Add action description

Example:
```php
add_action('search.autocomplete', function($data) {
    // Your code here
});
```

### `frontend.search_form`

Description: TODO - Add action description

Example:
```php
add_action('frontend.search_form', function($data) {
    // Your code here
});
```

