# Smart Shipping Calculator Hooks Documentation

## Overview

Hooks provided by the Smart Shipping Calculator plugin.

## Actions

### `checkout.shipping_methods`

Description: TODO - Add action description

Example:
```php
add_action('checkout.shipping_methods', function($data) {
    // Your code here
});
```

### `order.shipped`

Description: TODO - Add action description

Example:
```php
add_action('order.shipped', function($data) {
    // Your code here
});
```

### `shipping.rate_calculated`

Description: TODO - Add action description

Example:
```php
add_action('shipping.rate_calculated', function($data) {
    // Your code here
});
```

### `cart.updated`

Description: TODO - Add action description

Example:
```php
add_action('cart.updated', function($data) {
    // Your code here
});
```

