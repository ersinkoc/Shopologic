# social-commerce-integration Hooks Documentation

## Overview

Hooks provided by the social-commerce-integration plugin.

## Actions

### `social.post_created`

Description: TODO - Add action description

Example:
```php
add_action('social.post_created', function($data) {
    // Your code here
});
```

### `influencer.campaign_launched`

Description: TODO - Add action description

Example:
```php
add_action('influencer.campaign_launched', function($data) {
    // Your code here
});
```

### `social.engagement_tracked`

Description: TODO - Add action description

Example:
```php
add_action('social.engagement_tracked', function($data) {
    // Your code here
});
```

### `ugc.content_discovered`

Description: TODO - Add action description

Example:
```php
add_action('ugc.content_discovered', function($data) {
    // Your code here
});
```

### `social.order_attributed`

Description: TODO - Add action description

Example:
```php
add_action('social.order_attributed', function($data) {
    // Your code here
});
```

