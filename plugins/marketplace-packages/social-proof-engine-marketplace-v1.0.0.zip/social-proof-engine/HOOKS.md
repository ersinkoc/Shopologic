# Social Proof Engine Hooks Documentation

## Overview

Hooks provided by the Social Proof Engine plugin.

## Actions

### `order.completed`

Description: TODO - Add action description

Example:
```php
add_action('order.completed', function($data) {
    // Your code here
});
```

### `product.viewed`

Description: TODO - Add action description

Example:
```php
add_action('product.viewed', function($data) {
    // Your code here
});
```

### `cart.item_added`

Description: TODO - Add action description

Example:
```php
add_action('cart.item_added', function($data) {
    // Your code here
});
```

### `customer.registered`

Description: TODO - Add action description

Example:
```php
add_action('customer.registered', function($data) {
    // Your code here
});
```

### `frontend.footer`

Description: TODO - Add action description

Example:
```php
add_action('frontend.footer', function($data) {
    // Your code here
});
```

