# Subscription Commerce Hooks Documentation

## Overview

Hooks provided by the Subscription Commerce plugin.

## Actions

### `subscription.created`

Description: TODO - Add action description

Example:
```php
add_action('subscription.created', function($data) {
    // Your code here
});
```

### `subscription.renewed`

Description: TODO - Add action description

Example:
```php
add_action('subscription.renewed', function($data) {
    // Your code here
});
```

### `subscription.cancelled`

Description: TODO - Add action description

Example:
```php
add_action('subscription.cancelled', function($data) {
    // Your code here
});
```

### `billing.failed`

Description: TODO - Add action description

Example:
```php
add_action('billing.failed', function($data) {
    // Your code here
});
```

### `product.subscription_enabled`

Description: TODO - Add action description

Example:
```php
add_action('product.subscription_enabled', function($data) {
    // Your code here
});
```

