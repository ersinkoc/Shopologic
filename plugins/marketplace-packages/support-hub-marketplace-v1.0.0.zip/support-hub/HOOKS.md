# Customer Support Hub Hooks Documentation

## Overview

Hooks provided by the Customer Support Hub plugin.

## Actions

### `support.ticket_created`

Description: TODO - Add action description

Example:
```php
add_action('support.ticket_created', function($data) {
    // Your code here
});
```

### `chat.message_received`

Description: TODO - Add action description

Example:
```php
add_action('chat.message_received', function($data) {
    // Your code here
});
```

### `order.issue_reported`

Description: TODO - Add action description

Example:
```php
add_action('order.issue_reported', function($data) {
    // Your code here
});
```

### `frontend.chat_widget`

Description: TODO - Add action description

Example:
```php
add_action('frontend.chat_widget', function($data) {
    // Your code here
});
```

