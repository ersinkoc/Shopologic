# visual-page-builder Hooks Documentation

## Overview

Hooks provided by the visual-page-builder plugin.

## Actions

### `page.created`

Description: TODO - Add action description

Example:
```php
add_action('page.created', function($data) {
    // Your code here
});
```

### `page.updated`

Description: TODO - Add action description

Example:
```php
add_action('page.updated', function($data) {
    // Your code here
});
```

### `block.registered`

Description: TODO - Add action description

Example:
```php
add_action('block.registered', function($data) {
    // Your code here
});
```

### `template.saved`

Description: TODO - Add action description

Example:
```php
add_action('template.saved', function($data) {
    // Your code here
});
```

### `layout.generated`

Description: TODO - Add action description

Example:
```php
add_action('layout.generated', function($data) {
    // Your code here
});
```

## Filters

### `content.render`

Description: TODO - Add filter description

Example:
```php
add_filter('content.render', function($value) {
    return $value;
});
```

### `page.output`

Description: TODO - Add filter description

Example:
```php
add_filter('page.output', function($value) {
    return $value;
});
```

### `blocks.available`

Description: TODO - Add filter description

Example:
```php
add_filter('blocks.available', function($value) {
    return $value;
});
```

### `templates.list`

Description: TODO - Add filter description

Example:
```php
add_filter('templates.list', function($value) {
    return $value;
});
```

### `assets.enqueue`

Description: TODO - Add filter description

Example:
```php
add_filter('assets.enqueue', function($value) {
    return $value;
});
```

