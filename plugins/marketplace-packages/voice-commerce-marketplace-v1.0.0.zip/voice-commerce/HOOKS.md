# Voice Commerce Hooks Documentation

## Overview

Hooks provided by the Voice Commerce plugin.

## Actions

### `frontend.head`

Description: TODO - Add action description

Example:
```php
add_action('frontend.head', function($data) {
    // Your code here
});
```

### `product.search`

Description: TODO - Add action description

Example:
```php
add_action('product.search', function($data) {
    // Your code here
});
```

### `cart.actions`

Description: TODO - Add action description

Example:
```php
add_action('cart.actions', function($data) {
    // Your code here
});
```

### `checkout.navigation`

Description: TODO - Add action description

Example:
```php
add_action('checkout.navigation', function($data) {
    // Your code here
});
```

