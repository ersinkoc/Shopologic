# Wishlist Intelligence Hooks Documentation

## Overview

Hooks provided by the Wishlist Intelligence plugin.

## Actions

### `product.price_changed`

Description: TODO - Add action description

Example:
```php
add_action('product.price_changed', function($data) {
    // Your code here
});
```

### `product.back_in_stock`

Description: TODO - Add action description

Example:
```php
add_action('product.back_in_stock', function($data) {
    // Your code here
});
```

### `customer.dashboard`

Description: TODO - Add action description

Example:
```php
add_action('customer.dashboard', function($data) {
    // Your code here
});
```

